package tadPila;
//Revisado 29/09/2010

public class PilaVacia extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PilaVacia (final String msg) {
            super(msg);
        }
}
